import React from 'react';
import Dashboard from './Dashboard';
import 'bootstrap/dist/css/bootstrap.min.css';  // Import Bootstrap
import './index.css';  // Import CSS yang sudah diubah

function App() {
  return (
    <div className="App">
      <Dashboard />
    </div>
  );
}

export default App;

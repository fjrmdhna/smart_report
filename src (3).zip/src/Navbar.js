import React from 'react';
import { Navbar, Nav, Container } from 'react-bootstrap';
import { FaProjectDiagram } from 'react-icons/fa'; // Import ikon dari react-icons

const MyNavbar = () => {
  return (
    <Navbar bg="dark" variant="dark" expand="lg" className="custom-navbar">
      <Container>
        <Navbar.Brand href="#" className="navbar-brand-custom">
          <FaProjectDiagram style={{ marginRight: '10px' }} /> {/* Tambahkan Ikon */}
          Proyek Dashboard
        </Navbar.Brand>
        <Navbar.Toggle aria-controls="basic-navbar-nav" />
        <Navbar.Collapse id="basic-navbar-nav">
          <Nav className="mx-auto"> {/* Buat menu di tengah */}
            <Nav.Link href="#" className="nav-link-custom">Home</Nav.Link>
            <Nav.Link href="#" className="nav-link-custom">Upload</Nav.Link>
            <Nav.Link href="#" className="nav-link-custom">About</Nav.Link>
          </Nav>
        </Navbar.Collapse>
      </Container>
    </Navbar>
  );
};

export default MyNavbar;
